try:
	import pygame,sys,math,random,os,platform
	from pygame.locals import *
except ImportError as exception:
	print(f"[ERROR] => {exception}")
else:
	#SCREEN CONFIGURATION
	pygame.init()
	SIZE = pygame.display.Info().current_w, pygame.display.Info().current_h
	WIDTH,HEIGHT=800,800
	X, Y = (SIZE[0] - WIDTH)//2, (SIZE[1] - HEIGHT)//2
	os.environ["SDL_VIDEO_WINDOW_POS"] = "%d,%d" % (X, Y)
	pygame.display.set_caption("SNAKE BY THE WeReWoLf")
	clock = pygame.time.Clock()
	area = pygame.display.set_mode((WIDTH, HEIGHT), pygame.HWACCEL)


	#GAME VARIABLES
	width,height=40,40
	CONST_WIDTH, CONST_HEIGHT = WIDTH//width, HEIGHT//height
	apple = [random.randint(0,CONST_WIDTH-1)*width,random.randint(0,CONST_HEIGHT-1)*height]
	bodySnake = [[random.randint(0,CONST_WIDTH-1)*width,random.randint(0,CONST_HEIGHT-1)*height]]
	directions = ["up", "down", "left", "right"]
	direction = random.choice(directions)
	while bodySnake[0] == apple:
		bodySnake[0] = [random.randint(0,CONST_WIDTH-1)*width,random.randint(0,CONST_HEIGHT-1)*height]

	#GAME CONSTANTS
	WHITE = (255,255,255)
	RED = (255,0,0)
	GREEN = (0,255,0)
	BLUE = (0,0,255)
	APPLEIMAGE = pygame.transform.scale(pygame.image.load("apple.png"), (width, height))

	#DISPLAY ON THE SCREEN ITEMS
	def draw(surface):
		surface.fill(WHITE)
		surface.blit(APPLEIMAGE, (apple[0],apple[1]))
		#pygame.draw.rect(surface,RED,pygame.Rect(apple[0],apple[1],width,height))
		pygame.draw.rect(surface,GREEN,pygame.Rect(bodySnake[0][0], bodySnake[0][1], width, height))
		for k in range(1, len(bodySnake)):
			pygame.draw.rect(surface,BLUE,pygame.Rect(bodySnake[k][0],bodySnake[k][1],width,height))
		pygame.display.update()

	isStarted = True
	while isStarted:
		clock.tick(25)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				isStarted = False
			if event.type == pygame.KEYDOWN:
				key = pygame.key.get_pressed()
				if key[pygame.K_UP] and direction != directions[1]:
					direction = directions[0]
				if key[pygame.K_DOWN] and direction != directions[0]:
					direction = directions[1]
				if key[pygame.K_LEFT] and direction != directions[3]:
					direction = directions[2]
				if key[pygame.K_RIGHT] and direction != directions[2]:
					direction = directions[3]
		index = 0
		cond = True
		while(cond):
			#whenever the snakes overcome one the frame borders
			if index != len(bodySnake):
				if bodySnake[index][0] == -width:
					bodySnake[index][0] = WIDTH-width
					cond = False
				elif bodySnake[index][0] == WIDTH:
					bodySnake[index][0] = 0
					cond = False
				elif bodySnake[index][1] == -height:
					bodySnake[index][1] = HEIGHT-height
					cond = False
				elif bodySnake[index][1] == HEIGHT:
					bodySnake[index][1] = 0
					cond = False
				else:
					index+=1
			else:
				cond = False
		#Whenever the snake eats an apple with a position generated randomly
		if bodySnake[0] == apple:
			if direction == directions[0]:
				bodySnake.insert(0,[bodySnake[0][0],bodySnake[0][1]-height])
			if direction == directions[1]:
				bodySnake.insert(0,[bodySnake[0][0],bodySnake[0][1]+height])
			if direction == directions[2]:
				bodySnake.insert(0,[bodySnake[0][0]-width,bodySnake[0][1]])
			if direction == directions[3]:
				bodySnake.insert(0,[bodySnake[0][0]+width,bodySnake[0][1]])
			apple = [random.randint(0,CONST_WIDTH-1)*width,random.randint(0,CONST_HEIGHT-1)*height]
			var = 1
			while var != 0:
				var = 0
				for k in range(len(bodySnake)):
					if apple == bodySnake[0]:
						apple = [random.randint(0,CONST_WIDTH-1)*width,random.randint(0,CONST_HEIGHT-1)*height]
						var += 1
		#Whenever the snake moves forward without eats an apple
		else:
			if direction == directions[0]:
				bodySnake.insert(0,[bodySnake[0][0],bodySnake[0][1]-height])
			if direction == directions[1]:
				bodySnake.insert(0,[bodySnake[0][0],bodySnake[0][1]+height])
			if direction == directions[2]:
				bodySnake.insert(0,[bodySnake[0][0]-width,bodySnake[0][1]])
			if direction == directions[3]:
				bodySnake.insert(0,[bodySnake[0][0]+width,bodySnake[0][1]])
			c = len(bodySnake)-1
			del bodySnake[c]

		#Whenever the snake bites its tail
		var = 0
		for k in range(1,len(bodySnake)):
			if bodySnake[0] == bodySnake[k]:
				var += 1
		if var > 0:
			isStarted = False
			print("You didn't win!")
		draw(area)
	pygame.quit()
	sys.exit()
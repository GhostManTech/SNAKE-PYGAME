try:
	import pygame,sys,math,random,os,platform
	from pygame.locals import *
except ImportError as exception:
	print(f"[ERROR] => {exception}")
else:
	#SCREEN CONFIGURATION
	pygame.init()
	SIZE = pygame.display.Info().current_w, pygame.display.Info().current_h
	WIDTH,HEIGHT=800,800
	X, Y = (SIZE[0] - WIDTH)//2, (SIZE[1] - HEIGHT)//2
	os.environ["SDL_VIDEO_WINDOW_POS"] = "%d,%d" % (X, Y)
	clock = pygame.time.Clock()
	area = pygame.display.set_mode((WIDTH, HEIGHT), pygame.HWACCEL)
	pygame.mouse.set_visible(False)


	#GAME VARIABLES
	width,height=40,40
	score = 0
	CONST_WIDTH, CONST_HEIGHT = WIDTH//width, HEIGHT//height
	apple = [random.randint(0,CONST_WIDTH-1)*width,random.randint(0,CONST_HEIGHT-1)*height]
	bodySnake = [[random.randint(0,CONST_WIDTH-1)*width,random.randint(0,CONST_HEIGHT-1)*height]]
	directions = ["up", "down", "left", "right"]
	direction = random.choice(directions)
	while bodySnake[0] == apple:
		bodySnake[0] = [random.randint(0,CONST_WIDTH-1)*width,random.randint(0,CONST_HEIGHT-1)*height]

	#GAME CONSTANTS
	WHITE = (255,255,255)
	RED = (255,0,0)
	GREEN = (0,255,0)
	BLUE = (0,0,255)
	BLACK = (0,0,0)
	APPLE = pygame.transform.scale(pygame.image.load("ASSETS/IMGS/apple.png").convert_alpha(), (width, height))
	LEFT = pygame.transform.scale(pygame.image.load("ASSETS/IMGS/left.png").convert_alpha(), (width, height))
	RIGHT = pygame.transform.scale(pygame.image.load("ASSETS/IMGS/right.png").convert_alpha(), (width, height))
	DOWN = pygame.transform.scale(pygame.image.load("ASSETS/IMGS/down.png").convert_alpha(), (width, height))
	UP = pygame.transform.scale(pygame.image.load("ASSETS/IMGS/up.png").convert_alpha(), (width, height))


	#DISPLAY ON THE SCREEN ITEMS
	def draw(surface):
		surface.fill(WHITE)
		x = width
		for k in range(CONST_WIDTH-1):
			pygame.draw.line(surface, BLACK, [x, 0], [x, HEIGHT], 1)
			x+=width
		y = height
		for c in range(CONST_HEIGHT-1):
			pygame.draw.line(surface, BLACK, [0, y], [WIDTH, y], 1)
			y+=height
		surface.blit(APPLE, (apple[0],apple[1]))
		if direction == directions[0]:
			surface.blit(UP, (bodySnake[0][0], bodySnake[0][1]))
		if direction == directions[1]:
			surface.blit(DOWN, (bodySnake[0][0], bodySnake[0][1]))
		if direction == directions[2]:
			surface.blit(LEFT, (bodySnake[0][0], bodySnake[0][1]))
		if direction == directions[3]:
			surface.blit(RIGHT, (bodySnake[0][0], bodySnake[0][1]))
		for k in range(1, len(bodySnake)):
			pygame.draw.rect(surface,RED,pygame.Rect(bodySnake[k][0],bodySnake[k][1],width,height))
		pygame.display.update()

	def changeMatrix():
		global bodySnake
		if direction == directions[0]:
			bodySnake.insert(0,[bodySnake[0][0],bodySnake[0][1]-height])
		if direction == directions[1]:
			bodySnake.insert(0,[bodySnake[0][0],bodySnake[0][1]+height])
		if direction == directions[2]:
			bodySnake.insert(0,[bodySnake[0][0]-width,bodySnake[0][1]])
		if direction == directions[3]:
			bodySnake.insert(0,[bodySnake[0][0]+width,bodySnake[0][1]])

	isStarted = True
	while isStarted:
		clock.tick(20)
		pygame.display.set_caption(f"SCORE : {score}")
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				isStarted = False
			if event.type == pygame.KEYDOWN:
				if (event.key == pygame.K_w or event.key == pygame.K_UP) and direction != directions[1]:
					direction = directions[0]
				if (event.key == pygame.K_s or event.key == pygame.K_DOWN) and direction != directions[0]:
					direction = directions[1]
				if (event.key == pygame.K_a or event.key == pygame.K_LEFT) and direction != directions[3]:
					direction = directions[2]
				if (event.key == pygame.K_d or event.key == pygame.K_RIGHT) and direction != directions[2]:
					direction = directions[3]
		#Whenever the snake eats an apple with a position generated randomly
		if bodySnake[0] == apple:
			changeMatrix()
			apple = [random.randint(0,CONST_WIDTH-1)*width,random.randint(0,CONST_HEIGHT-1)*height]
			var = 1
			score += 1
			while var != 0:
				var = 0
				for k in range(len(bodySnake)):
					if apple == bodySnake[k]:
						apple = [random.randint(0,CONST_WIDTH-1)*width,random.randint(0,CONST_HEIGHT-1)*height]
						var += 1

		#Whenever the snake moves forward without eats an apple
		else:
			changeMatrix()
			c = len(bodySnake)-1
			del bodySnake[c]

		#Whenever the snake bites its tail
		var = 0
		for k in range(1,len(bodySnake)):
			if bodySnake[0] == bodySnake[k]:
				var += 1
		if var > 0:
			isStarted = False
			print("You didn't win because you bit your tail!")
		#Whenever you win
		if score == CONST_HEIGHT*CONST_WIDTH:
			isStarted = False
			print("You won!")
		#whenever the snakes overcome one the frame borders
		index = 0
		cond = True
		while(cond):
			if index != len(bodySnake):
				if bodySnake[index][0] <= -width:
					bodySnake[index][0] = WIDTH-width
					cond = False
				elif bodySnake[index][0] >= WIDTH:
					bodySnake[index][0] = 0
					cond = False
				elif bodySnake[index][1] <= -height:
					bodySnake[index][1] = HEIGHT-height
					cond = False
				elif bodySnake[index][1] >= HEIGHT:
					bodySnake[index][1] = 0
					cond = False
				else:
					index+=1
			else:
				cond = False
		draw(area)
	pygame.quit()
	sys.exit()